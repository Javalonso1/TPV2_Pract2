# SimpleJSON - [https://github.com/MJPA/SimpleJSON](https://github.com/MJPA/SimpleJSON)

SimpleJSON is a simple C++ code for parsing and generating JSON structures. The version in this directory is a modification of the original code to use std::string and std::char instead of std::wstring and wchar_t. For usage examples see the GitHub repository.



# TODO
 
* Instead of "return NULL" during parsing, it would be better to throw an exception explaining the error, etc.
